package com.crackit.crackitserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrackitserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrackitserverApplication.class, args);
	}

}
