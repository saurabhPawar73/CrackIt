package com.crackit.crackitserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrackitserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
